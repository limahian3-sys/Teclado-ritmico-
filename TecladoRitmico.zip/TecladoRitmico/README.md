# Teclado Rítmico (Android)

Transforma o celular em um **teclado Bluetooth** para jogos de ritmo (FNF e outros), com tela **hitbox** estilo Psych Engine Mobile.
Funciona em qualquer aparelho que aceite teclado Bluetooth: PC, Mac, Linux, tablet, outro celular, Steam Deck, TV...

## Gerar o APK
1. Instale o **Android Studio** (Koala ou mais novo) com JDK 17.
2. `File > Open` e escolha esta pasta (`TecladoRitmico`). Espere o "Gradle sync" terminar (precisa de internet na 1ª vez).
3. `Build > Build Bundle(s) / APK(s) > Build APK(s)`.
4. O arquivo fica em `app/build/outputs/apk/debug/app-debug.apk`. Passe para o celular e instale
   (permita "instalar apps de fontes desconhecidas").

Se o Android Studio reclamar de versões, aceite a sugestão "Update" do Gradle/AGP — o código não depende de versão específica.

## Usar
1. Abra o app e aceite as permissões de Bluetooth.
2. Toque em **Tornar este celular visível**.
3. No outro aparelho, abra o Bluetooth, procure "…" (o nome do seu celular) e **pareie**.
4. Volte ao app, toque no aparelho na lista (**Aparelhos pareados**) para conectar. O status mostra "● Conectado".
5. Escolha Hitbox/Botões, 4K–9K, as teclas de cada coluna e toque em **JOGAR**.
6. Dentro do jogo, o botão ⚙ no topo volta para os ajustes. Para trocar de aparelho, desconecte e conecte outro da lista.

## Limites
- Precisa de Android 9 ou mais novo. Alguns modelos (alguns Samsung/Xiaomi antigos) não liberam o modo teclado Bluetooth: o app avisa.
- Envia até 6 teclas ao mesmo tempo (padrão dos teclados Bluetooth).
- Consoles geralmente não aceitam teclado Bluetooth para jogar.
