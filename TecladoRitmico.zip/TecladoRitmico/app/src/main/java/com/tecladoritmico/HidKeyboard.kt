package com.tecladoritmico

import android.annotation.SuppressLint
import android.bluetooth.BluetoothAdapter
import android.bluetooth.BluetoothDevice
import android.bluetooth.BluetoothHidDevice
import android.bluetooth.BluetoothHidDeviceAppSdpSettings
import android.bluetooth.BluetoothManager
import android.bluetooth.BluetoothProfile
import android.content.Context
import java.util.concurrent.Executors

/**
 * Faz o celular se apresentar como um teclado Bluetooth (perfil HID Device, Android 9+).
 * Qualquer aparelho que aceite teclado Bluetooth (PC, Mac, tablet, outro celular, TV...)
 * pode parear e receber as teclas.
 *
 * [onChange] é chamado de uma thread de segundo plano: quem usa deve voltar para a thread da UI.
 */
@SuppressLint("MissingPermission")
class HidKeyboard(private val ctx: Context, private val onChange: () -> Unit) {

    private val adapter: BluetoothAdapter? =
        ctx.getSystemService(BluetoothManager::class.java)?.adapter

    private var hid: BluetoothHidDevice? = null
    private var starting = false
    private val exec = Executors.newSingleThreadExecutor()

    @Volatile
    var registered = false
        private set

    @Volatile
    var unsupported = false
        private set

    @Volatile
    var host: BluetoothDevice? = null
        private set

    private val pressed = ArrayList<Int>()
    private var mods = 0

    val hasAdapter: Boolean get() = adapter != null
    val bluetoothOn: Boolean get() = adapter?.isEnabled == true

    // ------------------------------------------------------------ ciclo de vida
    fun start() {
        val a = adapter ?: return
        if (!a.isEnabled || hid != null || starting) return
        starting = true
        val ok = try {
            a.getProfileProxy(ctx, listener, BluetoothProfile.HID_DEVICE)
        } catch (e: SecurityException) {
            starting = false
            return
        }
        if (!ok) {
            starting = false
            unsupported = true
            onChange()
        }
    }

    fun stop() {
        try {
            hid?.unregisterApp()
        } catch (e: Exception) {
        }
        try {
            hid?.let { adapter?.closeProfileProxy(BluetoothProfile.HID_DEVICE, it) }
        } catch (e: Exception) {
        }
        hid = null
        registered = false
        host = null
        starting = false
    }

    private val listener = object : BluetoothProfile.ServiceListener {
        override fun onServiceConnected(profile: Int, proxy: BluetoothProfile) {
            if (profile != BluetoothProfile.HID_DEVICE) return
            hid = proxy as BluetoothHidDevice
            starting = false
            register()
        }

        override fun onServiceDisconnected(profile: Int) {
            if (profile == BluetoothProfile.HID_DEVICE) {
                hid = null
                registered = false
                host = null
                starting = false
                onChange()
            }
        }
    }

    private val callback = object : BluetoothHidDevice.Callback() {
        override fun onAppStatusChanged(pluggedDevice: BluetoothDevice?, registered: Boolean) {
            this@HidKeyboard.registered = registered
            if (!registered) host = null
            onChange()
        }

        override fun onConnectionStateChanged(device: BluetoothDevice?, state: Int) {
            when (state) {
                BluetoothProfile.STATE_CONNECTED -> host = device
                BluetoothProfile.STATE_DISCONNECTED -> if (device == host) {
                    host = null
                    synchronized(this@HidKeyboard) { pressed.clear(); mods = 0 }
                }
            }
            onChange()
        }
    }

    private fun register() {
        val sdp = BluetoothHidDeviceAppSdpSettings(
            "Teclado Rítmico",
            "Teclado Bluetooth para jogos",
            "TecladoRitmico",
            BluetoothHidDevice.SUBCLASS1_KEYBOARD,
            DESCRIPTOR
        )
        try {
            hid?.registerApp(sdp, null, null, exec, callback)
        } catch (e: SecurityException) {
        }
    }

    // ------------------------------------------------------------ conexão
    fun bonded(): List<BluetoothDevice> =
        try {
            adapter?.bondedDevices?.toList() ?: emptyList()
        } catch (e: SecurityException) {
            emptyList()
        }

    fun connect(d: BluetoothDevice): Boolean = try {
        host?.let { if (it != d) hid?.disconnect(it) }
        hid?.connect(d) ?: false
    } catch (e: SecurityException) {
        false
    }

    fun disconnect() {
        try {
            host?.let { hid?.disconnect(it) }
        } catch (e: SecurityException) {
        }
    }

    // ------------------------------------------------------------ teclas
    @Synchronized
    fun keyDown(name: String) {
        val m = Keys.modifier(name)
        if (m != 0) {
            mods = mods or m
        } else {
            val u = Keys.usage(name) ?: return
            if (!pressed.contains(u)) pressed.add(u)
        }
        send()
    }

    @Synchronized
    fun keyUp(name: String) {
        val m = Keys.modifier(name)
        if (m != 0) {
            mods = mods and m.inv()
        } else {
            val u = Keys.usage(name) ?: return
            pressed.remove(u)
        }
        send()
    }

    @Synchronized
    fun releaseAll() {
        pressed.clear()
        mods = 0
        send()
    }

    /** Relatório de teclado padrão (6 teclas simultâneas): [mods, 0, k1..k6]. */
    private fun send() {
        val d = host ?: return
        val h = hid ?: return
        val r = ByteArray(8)
        r[0] = mods.toByte()
        for (i in 0 until minOf(6, pressed.size)) r[2 + i] = pressed[i].toByte()
        try {
            h.sendReport(d, REPORT_ID, r)
        } catch (e: SecurityException) {
        }
    }

    companion object {
        private const val REPORT_ID = 1

        /** Descritor HID de um teclado padrão com Report ID 1. */
        private val DESCRIPTOR: ByteArray = intArrayOf(
            0x05, 0x01,       // Usage Page (Generic Desktop)
            0x09, 0x06,       // Usage (Keyboard)
            0xA1, 0x01,       // Collection (Application)
            0x85, REPORT_ID,  //   Report ID (1)
            0x05, 0x07,       //   Usage Page (Key Codes)
            0x19, 0xE0,       //   Usage Minimum (Left Ctrl)
            0x29, 0xE7,       //   Usage Maximum (Right GUI)
            0x15, 0x00,       //   Logical Minimum (0)
            0x25, 0x01,       //   Logical Maximum (1)
            0x75, 0x01,       //   Report Size (1)
            0x95, 0x08,       //   Report Count (8)
            0x81, 0x02,       //   Input (Data, Variable, Absolute)  -> modificadores
            0x95, 0x01,       //   Report Count (1)
            0x75, 0x08,       //   Report Size (8)
            0x81, 0x01,       //   Input (Constant)                  -> reservado
            0x95, 0x05,       //   Report Count (5)
            0x75, 0x01,       //   Report Size (1)
            0x05, 0x08,       //   Usage Page (LEDs)
            0x19, 0x01,       //   Usage Minimum (Num Lock)
            0x29, 0x05,       //   Usage Maximum (Kana)
            0x91, 0x02,       //   Output (Data, Variable, Absolute) -> LEDs
            0x95, 0x01,       //   Report Count (1)
            0x75, 0x03,       //   Report Size (3)
            0x91, 0x01,       //   Output (Constant)                 -> preenchimento
            0x95, 0x06,       //   Report Count (6)
            0x75, 0x08,       //   Report Size (8)
            0x15, 0x00,       //   Logical Minimum (0)
            0x25, 0x65,       //   Logical Maximum (101)
            0x05, 0x07,       //   Usage Page (Key Codes)
            0x19, 0x00,       //   Usage Minimum (0)
            0x29, 0x65,       //   Usage Maximum (101)
            0x81, 0x00,       //   Input (Data, Array)               -> 6 teclas
            0xC0              // End Collection
        ).map { it.toByte() }.toByteArray()
    }
}
