package com.tecladoritmico

import android.content.Context
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.Paint
import android.graphics.RectF
import android.graphics.Typeface
import android.view.MotionEvent
import android.view.View

/**
 * Área de toque: modo "hitbox" (colunas ocupando a tela inteira, como no Psych Engine Mobile)
 * ou modo "botões". Multi-toque, com opção de deslizar o dedo entre colunas.
 */
class PadView(ctx: Context) : View(ctx) {

    var n = 4
        private set
    var binds: List<String> = emptyList()
        private set

    private var hitbox = true
    private var opacity = 55
    private var slide = true
    private var labels = true

    /** (coluna, pressionada?) */
    var onLane: ((Int, Boolean) -> Unit)? = null

    private val down = BooleanArray(16)
    private val ptr = HashMap<Int, Int>() // id do dedo -> coluna (-1 = fora)

    private val bg = Color.parseColor("#0B0B12")
    private val fnf = intArrayOf(
        Color.parseColor("#C24B99"), Color.parseColor("#00FFFF"),
        Color.parseColor("#12FA05"), Color.parseColor("#F9393F")
    )
    private val fill = Paint(Paint.ANTI_ALIAS_FLAG)
    private val stroke = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        style = Paint.Style.STROKE
        strokeWidth = 4f
    }
    private val line = Paint().apply {
        color = Color.argb(34, 255, 255, 255)
        strokeWidth = 2f
    }
    private val text = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        color = Color.WHITE
        textAlign = Paint.Align.CENTER
        typeface = Typeface.DEFAULT_BOLD
        setShadowLayer(8f, 0f, 2f, Color.argb(150, 0, 0, 0))
    }
    private val rect = RectF()

    fun configure(
        count: Int, hitbox: Boolean, opacity: Int, slide: Boolean, labels: Boolean, keys: List<String>
    ) {
        releaseAll()
        n = count
        binds = keys
        this.hitbox = hitbox
        this.opacity = opacity
        this.slide = slide
        this.labels = labels
        invalidate()
    }

    fun releaseAll() {
        ptr.clear()
        sync()
    }

    private fun dp(v: Int): Float = v * resources.displayMetrics.density

    private fun laneAt(x: Float, y: Float): Int {
        if (n == 0 || width == 0) return -1
        if (hitbox) return (x / width * n).toInt().coerceIn(0, n - 1)
        val edge = dp(14)
        val gap = dp(12)
        if (y < edge || y > height - edge) return -1
        val lw = (width - 2 * edge - (n - 1) * gap) / n
        for (i in 0 until n) {
            val l = edge + i * (lw + gap)
            if (x >= l && x <= l + lw) return i
        }
        return -1
    }

    override fun onTouchEvent(e: MotionEvent): Boolean {
        when (e.actionMasked) {
            MotionEvent.ACTION_DOWN, MotionEvent.ACTION_POINTER_DOWN -> {
                val i = e.actionIndex
                ptr[e.getPointerId(i)] = laneAt(e.getX(i), e.getY(i))
            }
            MotionEvent.ACTION_MOVE -> if (slide) {
                for (i in 0 until e.pointerCount) {
                    val id = e.getPointerId(i)
                    if (ptr.containsKey(id)) ptr[id] = laneAt(e.getX(i), e.getY(i))
                }
            }
            MotionEvent.ACTION_UP, MotionEvent.ACTION_POINTER_UP -> ptr.remove(e.getPointerId(e.actionIndex))
            MotionEvent.ACTION_CANCEL -> ptr.clear()
        }
        sync()
        return true
    }

    /** Compara as colunas tocadas agora com as anteriores e avisa só o que mudou. */
    private fun sync() {
        val now = BooleanArray(16)
        for (l in ptr.values) if (l in 0 until n) now[l] = true
        for (i in 0 until n) {
            if (now[i] != down[i]) {
                down[i] = now[i]
                onLane?.invoke(i, now[i])
            }
        }
        invalidate()
    }

    private fun colorOf(i: Int): Int =
        if (n == 4) fnf[i] else Color.HSVToColor(floatArrayOf((i * 360f / n + 270f) % 360f, 0.65f, 1f))

    override fun onDraw(c: Canvas) {
        c.drawColor(bg)
        if (n == 0) return
        val op = opacity / 100f
        val w = width.toFloat()
        val h = height.toFloat()
        val edge = if (hitbox) 0f else dp(14)
        val gap = if (hitbox) 0f else dp(12)
        val lw = (w - 2 * edge - (n - 1) * gap) / n
        text.textSize = minOf(lw * 0.5f, h * 0.35f)

        for (i in 0 until n) {
            val col = colorOf(i)
            val a = if (down[i]) minOf(1f, 0.30f + op * 0.70f) else op * 0.45f
            val left = edge + i * (lw + gap)
            rect.set(left, edge, left + lw, h - edge)

            fill.color = col
            fill.alpha = (a * 255).toInt()
            if (hitbox) {
                c.drawRect(rect, fill)
                if (i < n - 1) c.drawLine(rect.right, 0f, rect.right, h, line)
            } else {
                c.drawRoundRect(rect, dp(22), dp(22), fill)
                stroke.color = col
                stroke.alpha = (minOf(1f, a + 0.3f) * 255).toInt()
                c.drawRoundRect(rect, dp(22), dp(22), stroke)
            }
            if (labels) {
                val t = Keys.glyph(binds.getOrNull(i) ?: "")
                c.drawText(t, rect.centerX(), rect.centerY() - (text.ascent() + text.descent()) / 2f, text)
            }
        }
    }
}
