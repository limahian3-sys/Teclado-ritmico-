package com.tecladoritmico

import android.Manifest
import android.app.Activity
import android.bluetooth.BluetoothAdapter
import android.bluetooth.BluetoothDevice
import android.content.Intent
import android.content.pm.ActivityInfo
import android.content.pm.PackageManager
import android.graphics.Color
import android.graphics.Typeface
import android.os.Build
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.os.VibrationEffect
import android.os.Vibrator
import android.provider.Settings
import android.view.Gravity
import android.view.MotionEvent
import android.view.View
import android.view.ViewGroup
import android.view.WindowManager
import android.widget.AdapterView
import android.widget.ArrayAdapter
import android.widget.Button
import android.widget.CheckBox
import android.widget.FrameLayout
import android.widget.LinearLayout
import android.widget.RadioButton
import android.widget.RadioGroup
import android.widget.ScrollView
import android.widget.SeekBar
import android.widget.Spinner
import android.widget.TextView
import android.widget.Toast

class MainActivity : Activity() {

    private lateinit var prefs: Prefs
    private lateinit var hid: HidKeyboard
    private lateinit var root: FrameLayout
    private lateinit var pad: PadView

    private val ui = Handler(Looper.getMainLooper())
    private var vibrator: Vibrator? = null
    private var playing = false

    private var statusSetup: TextView? = null
    private var statusPlay: TextView? = null
    private var devicesBox: LinearLayout? = null
    private var bindsBox: LinearLayout? = null

    private val MATCH = ViewGroup.LayoutParams.MATCH_PARENT
    private val WRAP = ViewGroup.LayoutParams.WRAP_CONTENT
    private val bg = Color.parseColor("#0B0B12")
    private val muted = Color.parseColor("#9A9AB5")

    // ------------------------------------------------------------ ciclo de vida
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        prefs = Prefs(this)
        vibrator = getSystemService(Vibrator::class.java)

        root = FrameLayout(this)
        root.setBackgroundColor(bg)
        setContentView(root)

        pad = PadView(this)
        pad.onLane = { i, isDown ->
            val k = pad.binds.getOrNull(i)
            if (k != null) {
                if (isDown) {
                    hid.keyDown(k)
                    buzz()
                } else {
                    hid.keyUp(k)
                }
            }
        }

        hid = HidKeyboard(this) { ui.post { refreshStatus() } }
        showSetup()
        ensurePerms()
    }

    override fun onResume() {
        super.onResume()
        hid.start()
        refreshStatus()
    }

    override fun onPause() {
        super.onPause()
        pad.releaseAll()
        hid.releaseAll()
    }

    override fun onDestroy() {
        super.onDestroy()
        hid.stop()
    }

    @Suppress("DEPRECATION")
    override fun onBackPressed() {
        if (playing) showSetup() else super.onBackPressed()
    }

    private fun ensurePerms() {
        if (Build.VERSION.SDK_INT >= 31) {
            val need = listOf(
                Manifest.permission.BLUETOOTH_CONNECT,
                Manifest.permission.BLUETOOTH_ADVERTISE
            ).filter { checkSelfPermission(it) != PackageManager.PERMISSION_GRANTED }
            if (need.isNotEmpty()) {
                requestPermissions(need.toTypedArray(), 1)
                return
            }
        }
        hid.start()
    }

    override fun onRequestPermissionsResult(
        requestCode: Int, permissions: Array<out String>, grantResults: IntArray
    ) {
        super.onRequestPermissionsResult(requestCode, permissions, grantResults)
        hid.start()
        refreshStatus()
    }

    // ------------------------------------------------------------ utilidades
    private fun dp(v: Int): Int = (v * resources.displayMetrics.density).toInt()

    private fun buzz() {
        if (prefs.vibrate) {
            vibrator?.vibrate(VibrationEffect.createOneShot(8, VibrationEffect.DEFAULT_AMPLITUDE))
        }
    }

    private fun toast(t: String) = Toast.makeText(this, t, Toast.LENGTH_SHORT).show()

    private fun nameOf(d: BluetoothDevice?): String =
        try {
            d?.name ?: d?.address ?: "aparelho"
        } catch (e: SecurityException) {
            "aparelho"
        }

    private fun label(t: String, sp: Float = 15f, color: Int = Color.WHITE, bold: Boolean = false) =
        TextView(this).apply {
            text = t
            textSize = sp
            setTextColor(color)
            if (bold) setTypeface(typeface, Typeface.BOLD)
            setPadding(0, dp(6), 0, dp(6))
        }

    private fun button(t: String, onClick: () -> Unit) = Button(this).apply {
        text = t
        isAllCaps = false
        setOnClickListener { onClick() }
    }

    private fun check(t: String, v: Boolean, on: (Boolean) -> Unit) = CheckBox(this).apply {
        text = t
        isChecked = v
        setOnCheckedChangeListener { _, b -> on(b) }
    }

    @Suppress("DEPRECATION")
    private fun immersive(on: Boolean) {
        window.decorView.systemUiVisibility = if (on) {
            View.SYSTEM_UI_FLAG_IMMERSIVE_STICKY or View.SYSTEM_UI_FLAG_HIDE_NAVIGATION or
                View.SYSTEM_UI_FLAG_FULLSCREEN or View.SYSTEM_UI_FLAG_LAYOUT_STABLE or
                View.SYSTEM_UI_FLAG_LAYOUT_HIDE_NAVIGATION or View.SYSTEM_UI_FLAG_LAYOUT_FULLSCREEN
        } else {
            0
        }
    }

    // ------------------------------------------------------------ tela de ajustes / conexão
    private fun showSetup() {
        playing = false
        pad.releaseAll()
        hid.releaseAll()
        requestedOrientation = ActivityInfo.SCREEN_ORIENTATION_UNSPECIFIED
        window.clearFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON)
        immersive(false)
        statusPlay = null

        val col = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(dp(16), dp(16), dp(16), dp(40))
        }
        val sv = ScrollView(this).apply { addView(col) }
        root.removeAllViews()
        root.addView(sv, FrameLayout.LayoutParams(MATCH, MATCH))

        col.addView(label("Teclado Rítmico", 24f, bold = true))
        val stSetup = label("", 15f, Color.parseColor("#FFC145"), true)
        statusSetup = stSetup
        col.addView(stSetup)

        // --- conexão
        col.addView(label("COMO CONECTAR", 12f, muted, true))
        col.addView(
            label(
                "1. Toque em “Tornar visível”.\n" +
                    "2. No outro aparelho (PC, tablet, celular, TV…), abra o Bluetooth e pareie com este celular.\n" +
                    "3. Volte aqui e toque no aparelho na lista para conectar.",
                14f, Color.parseColor("#DDDDEE")
            )
        )
        col.addView(button("Tornar este celular visível (2 min)") {
            try {
                startActivity(
                    Intent(BluetoothAdapter.ACTION_REQUEST_DISCOVERABLE)
                        .putExtra(BluetoothAdapter.EXTRA_DISCOVERABLE_DURATION, 120)
                )
            } catch (e: Exception) {
                toast("Não foi possível abrir a tela de visibilidade")
            }
        })
        col.addView(button("Abrir ajustes de Bluetooth") {
            try {
                startActivity(Intent(Settings.ACTION_BLUETOOTH_SETTINGS))
            } catch (e: Exception) {
            }
        })

        col.addView(label("APARELHOS PAREADOS (toque para conectar)", 12f, muted, true))
        val dBox = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL }
        devicesBox = dBox
        col.addView(dBox)
        col.addView(button("Atualizar lista") { refreshDevices() })
        col.addView(button("Desconectar") { hid.disconnect() })

        // --- layout
        col.addView(label("ESTILO", 12f, muted, true))
        val rgMode = RadioGroup(this).apply { orientation = RadioGroup.HORIZONTAL }
        val rbHit = RadioButton(this).apply { text = "Hitbox (tela inteira)"; id = View.generateViewId() }
        val rbBtn = RadioButton(this).apply { text = "Botões"; id = View.generateViewId() }
        rgMode.addView(rbHit)
        rgMode.addView(rbBtn)
        rgMode.check(if (prefs.hitbox) rbHit.id else rbBtn.id)
        rgMode.setOnCheckedChangeListener { _, id -> prefs.hitbox = (id == rbHit.id) }
        col.addView(rgMode)

        col.addView(label("QUANTIDADE DE TECLAS", 12f, muted, true))
        val rgN = RadioGroup(this).apply { orientation = RadioGroup.HORIZONTAL }
        val ids = HashMap<Int, Int>()
        for (k in listOf(4, 5, 6, 7, 9)) {
            val rb = RadioButton(this).apply { text = "${k}K"; id = View.generateViewId() }
            ids[rb.id] = k
            rgN.addView(rb)
            if (k == prefs.n) rgN.check(rb.id)
        }
        rgN.setOnCheckedChangeListener { _, id ->
            val k = ids[id]
            if (k != null) {
                prefs.n = k
                rebuildBinds()
            }
        }
        col.addView(rgN)

        col.addView(label("TECLA DE CADA COLUNA", 12f, muted, true))
        val bBox = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL }
        bindsBox = bBox
        col.addView(bBox)
        rebuildBinds()

        // --- ajustes
        col.addView(label("AJUSTES", 12f, muted, true))
        col.addView(label("Opacidade dos botões"))
        col.addView(SeekBar(this).apply {
            max = 85
            progress = prefs.opacity - 15
            setOnSeekBarChangeListener(object : SeekBar.OnSeekBarChangeListener {
                override fun onProgressChanged(s: SeekBar?, p: Int, fromUser: Boolean) {
                    prefs.opacity = p + 15
                }

                override fun onStartTrackingTouch(s: SeekBar?) {}
                override fun onStopTrackingTouch(s: SeekBar?) {}
            })
        })
        col.addView(check("Vibrar ao tocar", prefs.vibrate) { prefs.vibrate = it })
        col.addView(check("Deslizar o dedo entre colunas", prefs.slide) { prefs.slide = it })
        col.addView(check("Mostrar setas/letras", prefs.labels) { prefs.labels = it })

        col.addView(Button(this).apply {
            text = "▶  JOGAR"
            textSize = 20f
            setOnClickListener { showPlay() }
        }, LinearLayout.LayoutParams(MATCH, WRAP).apply { topMargin = dp(24) })

        refreshStatus()
    }

    private fun rebuildBinds() {
        val box = bindsBox ?: return
        box.removeAllViews()
        val n = prefs.n
        if (n == 4) {
            val row = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL }
            for ((name, keys) in Keys.PRE4) {
                row.addView(button(name) {
                    prefs.setBinds(4, keys)
                    rebuildBinds()
                })
            }
            box.addView(row)
        }
        val cur = prefs.binds(n)
        for (i in 0 until n) {
            val row = LinearLayout(this).apply {
                orientation = LinearLayout.HORIZONTAL
                gravity = Gravity.CENTER_VERTICAL
            }
            row.addView(label("Coluna ${i + 1}"), LinearLayout.LayoutParams(0, WRAP, 1f))
            val sp = Spinner(this)
            sp.adapter = ArrayAdapter(this, android.R.layout.simple_spinner_dropdown_item, Keys.NAMES)
            sp.setSelection(Keys.NAMES.indexOf(cur[i]))
            sp.onItemSelectedListener = object : AdapterView.OnItemSelectedListener {
                override fun onItemSelected(p: AdapterView<*>?, v: View?, pos: Int, id: Long) {
                    val k = Keys.NAMES[pos]
                    val list = prefs.binds(n).toMutableList()
                    if (list[i] != k) {
                        list[i] = k
                        prefs.setBinds(n, list)
                    }
                }

                override fun onNothingSelected(p: AdapterView<*>?) {}
            }
            row.addView(sp, LinearLayout.LayoutParams(0, WRAP, 1f))
            box.addView(row)
        }
        box.addView(button("Restaurar padrão de ${n}K") {
            prefs.setBinds(n, Keys.DEF.getValue(n))
            rebuildBinds()
        })
    }

    private fun refreshDevices() {
        val box = devicesBox ?: return
        box.removeAllViews()
        val list = hid.bonded()
        if (list.isEmpty()) {
            box.addView(label("Nenhum aparelho pareado ainda.", 14f, muted))
            return
        }
        for (d in list) {
            val connected = d == hid.host
            box.addView(button((if (connected) "● " else "") + nameOf(d)) {
                if (hid.connect(d)) toast("Conectando a ${nameOf(d)}…")
                else toast("Não foi possível conectar (o modo teclado está ativo?)")
            })
        }
    }

    private fun refreshStatus() {
        val h = hid.host
        val full = when {
            !hid.hasAdapter -> "⚠ Este aparelho não tem Bluetooth."
            !hid.bluetoothOn -> "⚠ Ligue o Bluetooth e volte ao app."
            hid.unsupported -> "⚠ Este aparelho não suporta o modo teclado Bluetooth."
            !hid.registered -> "Preparando… (aceite as permissões de Bluetooth)"
            h != null -> "● Conectado a ${nameOf(h)}"
            else -> "○ Pronto. Aguardando conexão."
        }
        statusSetup?.text = full
        statusPlay?.text = if (h != null) "● ${nameOf(h)}" else "○ sem conexão"
        if (!playing) refreshDevices()
    }

    // ------------------------------------------------------------ tela de jogo
    private fun showPlay() {
        playing = true
        val n = prefs.n
        pad.configure(n, prefs.hitbox, prefs.opacity, prefs.slide, prefs.labels, prefs.binds(n))

        requestedOrientation = ActivityInfo.SCREEN_ORIENTATION_SENSOR_LANDSCAPE
        window.addFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON)
        immersive(true)
        statusSetup = null
        devicesBox = null
        bindsBox = null

        root.removeAllViews()
        (pad.parent as? ViewGroup)?.removeView(pad)
        root.addView(pad, FrameLayout.LayoutParams(MATCH, MATCH))

        val bar = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER_VERTICAL
            alpha = 0.75f
        }
        bar.addView(smallButton("⚙") { showSetup() })
        val stPlay = TextView(this).apply {
            textSize = 12f
            setTextColor(Color.WHITE)
            setPadding(dp(8), 0, dp(8), 0)
        }
        statusPlay = stPlay
        bar.addView(stPlay)
        for (k in listOf("esc", "enter", "r")) bar.addView(keyButton(k))
        root.addView(bar, FrameLayout.LayoutParams(WRAP, WRAP, Gravity.TOP or Gravity.CENTER_HORIZONTAL))

        refreshStatus()
    }

    private fun smallButton(t: String, onClick: () -> Unit) = Button(this).apply {
        text = t
        textSize = 12f
        isAllCaps = false
        minWidth = 0
        minimumWidth = 0
        setPadding(dp(10), 0, dp(10), 0)
        setOnClickListener { onClick() }
    }

    private fun keyButton(k: String) = smallButton(Keys.glyph(k)) {}.apply {
        setOnClickListener(null)
        setOnTouchListener { v, e ->
            when (e.actionMasked) {
                MotionEvent.ACTION_DOWN -> {
                    v.isPressed = true
                    hid.keyDown(k)
                    buzz()
                }
                MotionEvent.ACTION_UP, MotionEvent.ACTION_CANCEL -> {
                    v.isPressed = false
                    hid.keyUp(k)
                }
            }
            true
        }
    }
}
