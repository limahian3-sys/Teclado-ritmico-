package com.tecladoritmico

import android.content.Context

class Prefs(ctx: Context) {
    private val p = ctx.getSharedPreferences("tr", Context.MODE_PRIVATE)

    var n: Int
        get() = p.getInt("n", 4)
        set(v) { p.edit().putInt("n", v).apply() }

    var hitbox: Boolean
        get() = p.getBoolean("hitbox", true)
        set(v) { p.edit().putBoolean("hitbox", v).apply() }

    var opacity: Int
        get() = p.getInt("op", 55)
        set(v) { p.edit().putInt("op", v).apply() }

    var vibrate: Boolean
        get() = p.getBoolean("vib", true)
        set(v) { p.edit().putBoolean("vib", v).apply() }

    var slide: Boolean
        get() = p.getBoolean("slide", true)
        set(v) { p.edit().putBoolean("slide", v).apply() }

    var labels: Boolean
        get() = p.getBoolean("labels", true)
        set(v) { p.edit().putBoolean("labels", v).apply() }

    fun binds(n: Int): List<String> {
        val s = p.getString("b$n", null)?.split(",")
        val ok = s != null && s.size == n && s.all { Keys.usage(it) != null || Keys.modifier(it) != 0 }
        return if (ok) s!! else Keys.DEF.getValue(n)
    }

    fun setBinds(n: Int, l: List<String>) {
        p.edit().putString("b$n", l.joinToString(",")).apply()
    }
}
