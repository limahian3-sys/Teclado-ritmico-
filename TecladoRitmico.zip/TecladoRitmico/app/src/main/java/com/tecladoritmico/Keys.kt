package com.tecladoritmico

/** Nomes de teclas usados no app e a tabela de códigos HID (Usage Page 0x07). */
object Keys {
    val NAMES: List<String> =
        ('a'..'z').map { it.toString() } +
            (0..9).map { it.toString() } +
            listOf("left", "down", "up", "right", "space", "enter", "esc", "tab", "shift", "ctrl", "alt", "backspace") +
            (1..12).map { "f$it" }

    val DEF: Map<Int, List<String>> = mapOf(
        4 to listOf("left", "down", "up", "right"),
        5 to listOf("left", "down", "space", "up", "right"),
        6 to listOf("s", "d", "f", "j", "k", "l"),
        7 to listOf("s", "d", "f", "space", "j", "k", "l"),
        9 to listOf("a", "s", "d", "f", "space", "h", "j", "k", "l")
    )

    val PRE4: Map<String, List<String>> = linkedMapOf(
        "Setas" to listOf("left", "down", "up", "right"),
        "DFJK" to listOf("d", "f", "j", "k"),
        "WASD" to listOf("a", "s", "w", "d")
    )

    private val SPECIAL = mapOf(
        "enter" to 0x28, "esc" to 0x29, "backspace" to 0x2A, "tab" to 0x2B, "space" to 0x2C,
        "right" to 0x4F, "left" to 0x50, "down" to 0x51, "up" to 0x52
    )

    /** Código HID da tecla, ou null se for modificador/desconhecida. */
    fun usage(name: String): Int? {
        SPECIAL[name]?.let { return it }
        if (name.length == 1) {
            val c = name[0]
            if (c in 'a'..'z') return 0x04 + (c - 'a')
            if (c in '1'..'9') return 0x1E + (c - '1')
            if (c == '0') return 0x27
        }
        if (name.length > 1 && name[0] == 'f') {
            val n = name.substring(1).toIntOrNull()
            if (n != null && n in 1..12) return 0x3A + (n - 1)
        }
        return null
    }

    /** Bit do modificador no primeiro byte do relatório HID (0 se não for modificador). */
    fun modifier(name: String): Int = when (name) {
        "ctrl" -> 0x01
        "shift" -> 0x02
        "alt" -> 0x04
        else -> 0
    }

    fun glyph(name: String): String = when (name) {
        "left" -> "←"
        "down" -> "↓"
        "up" -> "↑"
        "right" -> "→"
        "space" -> "␣"
        "enter" -> "⏎"
        "backspace" -> "⌫"
        "shift" -> "⇧"
        else -> name.uppercase()
    }
}
